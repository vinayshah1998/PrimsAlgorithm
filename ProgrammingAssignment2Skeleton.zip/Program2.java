/**
 * Created by tkalbar on 3/2/19.
 */

public class Program2 {

    public int constructIntensityGraph(int[][] image){
        // TODO
        return 0;
    }

    public int constructPrunedGraph(int[][] image){
        // TODO
        return 0;
    }

}
